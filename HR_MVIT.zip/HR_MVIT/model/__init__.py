from .hrnet_origin import Mobile_HR_ViT
from .model20230811 import HR_MiT_Snet
from .shuffleNet_channel_2 import ShuffleNetV2_channel_02
from .shuffleNet_channel_3 import ShuffleNetV2_channel_03


