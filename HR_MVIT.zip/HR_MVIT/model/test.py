import torch
import torch.nn as nn
import math


def channel_shuffle(x, groups):
    """通道混洗操作

    将通道分割成几组,并打乱顺序
    """

    # 获取当前输入通道数
    batchsize, num_channels, height, width = x.data.size()

    # 分成groups组
    channels_per_group = num_channels // groups

    # reshape
    x = x.view(batchsize, groups,
               channels_per_group, height, width)

    # 打乱顺序
    x = torch.transpose(x, 1, 2).contiguous()

    # 平整
    x = x.view(batchsize, -1, height, width)

    return x


# 示例
x = torch.rand(1, 128, 256, 256)
x = channel_shuffle(x, 4)
print(x.shape)  # torch.Size([1, 128, 32, 32])


class GhostModule(nn.Module):
    def __init__(self, inp, oup, kernel_size=1, ratio=2, dw_size=3, stride=1, relu=True):
        super(GhostModule, self).__init__()
        self.oup = oup
        init_channels = math.ceil(oup / ratio)
        new_channels = init_channels * (ratio - 1)

        self.primary_conv = nn.Sequential(
            nn.Conv2d(inp, init_channels, kernel_size, stride, kernel_size // 2, bias=False),
            nn.BatchNorm2d(init_channels),
            nn.ReLU(inplace=True) if relu else nn.Sequential(), )
        # cheap操作，注意利用了分组卷积进行通道分离
        self.cheap_operation = nn.Sequential(
            nn.Conv2d(init_channels, new_channels, dw_size, 1, dw_size // 2, groups=init_channels, bias=False),
            nn.BatchNorm2d(new_channels),
            nn.ReLU(inplace=True) if relu else nn.Sequential(), )

    def forward(self, x):
        x1 = self.primary_conv(x)  # 主要的卷积操作
        x2 = self.cheap_operation(x1)  # cheap变换操作
        out = torch.cat([x1, x2], dim=1)  # 二者cat到一起
        return out[:, :self.oup, :, :]


G1 = GhostModule(128,128)
x = G1(x)
print(x.shape)
