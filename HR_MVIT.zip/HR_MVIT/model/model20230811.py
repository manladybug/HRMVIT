import math
from collections import OrderedDict
from torch.nn import init
from einops import rearrange
import numpy as np
from torch import nn
from torch.autograd import Variable
import torch
import torch.nn.functional as F
from train_utils import plot_tensor as P
from model import shuffleNet_channel_2 as SC2
from model import shuffleNet_channel_3 as SC3
import os
import matplotlib.pyplot as plt
from torch.nn import Dropout

BN_MOMENTUM = 0.99
DROPOUT = 0.5

"""这一部分是深度可分离卷积，降低传统卷积的参数"""


class DepthWiseConv(nn.Module):
    def __init__(self, in_channel, out_channel, kernel_size, stride, padding):
        # 这一行千万不要忘记
        super(DepthWiseConv, self).__init__()

        # 逐通道卷积
        self.depth_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=in_channel,
                                    kernel_size=kernel_size,
                                    stride=stride,
                                    padding=padding,
                                    groups=in_channel)
        # groups是一个数，当groups=in_channel时,表示做逐通道卷积

        # 逐点卷积
        self.point_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=out_channel,
                                    kernel_size=1,
                                    stride=1,
                                    padding=0,
                                    groups=1)

    def forward(self, input):
        out = self.depth_conv(input)
        out = self.point_conv(out)
        return out


"""低消耗拓展通道量"""


class GhostModule(nn.Module):
    def __init__(self, inp, oup, kernel_size=3, ratio=2, dw_size=3, stride=1, relu=True):
        super(GhostModule, self).__init__()
        self.oup = oup
        init_channels = math.ceil(oup / ratio)
        new_channels = init_channels * (ratio - 1)

        self.primary_conv = nn.Sequential(
            nn.Conv2d(inp, init_channels, kernel_size, stride, kernel_size // 2, bias=False),
            nn.BatchNorm2d(init_channels),
            nn.ReLU(inplace=True) if relu else nn.Sequential(), )
        # cheap操作，注意利用了分组卷积进行通道分离
        self.cheap_operation = nn.Sequential(
            nn.Conv2d(init_channels, new_channels, dw_size, 1, dw_size // 2, groups=init_channels, bias=False),
            nn.BatchNorm2d(new_channels),
            nn.ReLU(inplace=True) if relu else nn.Sequential(), )

    def forward(self, x):
        x1 = self.primary_conv(x)  # 主要的卷积操作
        x2 = self.cheap_operation(x1)  # cheap变换操作
        out = torch.cat([x1, x2], dim=1)  # 二者cat到一起
        return out[:, :self.oup, :, :]


""" START  MobileVit 部分"""


def conv_1x1_bn(inp, oup):
    return nn.Sequential(
        nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
        nn.BatchNorm2d(oup),
        nn.SiLU()
    )


def conv_nxn_bn(inp, oup, kernal_size=3, stride=1):
    return nn.Sequential(
        nn.Conv2d(inp, oup, kernal_size, stride, 1, bias=False),
        nn.BatchNorm2d(oup),
        nn.SiLU()
    )


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.attend = nn.Softmax(dim=-1)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b p n (h d) -> b p h n d', h=self.heads), qkv)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        attn = self.attend(dots)
        out = torch.matmul(attn, v)
        out = rearrange(out, 'b p h n d -> b p n (h d)')
        return self.to_out(out)


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout=0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                PreNorm(dim, Attention(dim, heads, dim_head, dropout)),
                PreNorm(dim, FeedForward(dim, mlp_dim, dropout))
            ]))

    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x


class MV2Block(nn.Module):
    def __init__(self, inp, oup, stride=1, expansion=4):
        super().__init__()
        self.stride = stride
        assert stride in [1, 2]

        hidden_dim = int(inp * expansion)
        self.use_res_connect = self.stride == 1 and inp == oup

        if expansion == 1:
            self.conv = nn.Sequential(
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.SiLU(),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )
        else:
            self.conv = nn.Sequential(
                # pw
                nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.SiLU(),
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.SiLU(),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )

    def forward(self, x):
        if self.use_res_connect:
            return x + self.conv(x)
        else:
            return self.conv(x)


class MobileViTBlock(nn.Module):
    def __init__(self, dim, depth, channel, kernel_size, patch_size, mlp_dim, dropout=0.):
        super().__init__()
        self.ph, self.pw = patch_size

        self.conv1 = conv_nxn_bn(channel, channel, kernel_size)
        self.conv2 = conv_1x1_bn(channel, dim)

        self.transformer = Transformer(dim, depth, 4, 8, mlp_dim, dropout)

        self.conv3 = conv_1x1_bn(dim, channel)
        self.conv4 = conv_nxn_bn(2 * channel, channel, kernel_size)

    def forward(self, x):
        y = x.clone()

        # Local representations
        x = self.conv1(x)
        x = self.conv2(x)

        # Global representations
        _, _, h, w = x.shape
        x = rearrange(x, 'b d (h ph) (w pw) -> b (ph pw) (h w) d', ph=self.ph, pw=self.pw)
        x = self.transformer(x)
        x = rearrange(x, 'b (ph pw) (h w) d -> b d (h ph) (w pw)', h=h // self.ph, w=w // self.pw, ph=self.ph,
                      pw=self.pw)
        # Fusion
        x = self.conv3(x)
        x = torch.cat((x, y), 1)
        x = self.conv4(x)
        return x


""" END  MobileVit 部分"""
"""特征融合模块"""


class fuse_Block(nn.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = nn.Conv2d(32, 17, 1)

        self.conv2 = nn.Conv2d(64, 17, 1)
        self.conv3 = nn.Conv2d(128, 17, 1)

        self.BN = nn.BatchNorm2d(17, momentum=BN_MOMENTUM)
        self.relu = nn.ReLU6()

    def forward(self, feat1, feat2, feat3):
        # 计算每个特征图的权重,分辨率越高权重越大
        weights = [0.5, 0.3, 0.2]

        feat1 = self.conv1(feat1)
        feat1 = self.BN(feat1)
        feat1 = self.relu(feat1)

        feat2 = self.conv2(feat2)
        feat2 = self.BN(feat2)
        feat2 = self.relu(feat2)

        feat3 = self.conv3(feat3)
        feat3 = self.BN(feat3)
        feat3 = self.relu(feat3)

        # 使用双线性插值调整spatial尺寸
        feat1 = nn.functional.interpolate(feat1, size=(32, 24), mode='bilinear')
        feat1 = self.BN(feat1)
        feat1 = self.relu(feat1)
        feat2 = nn.functional.interpolate(feat2, size=(32, 24), mode='bilinear')
        feat2 = self.BN(feat2)
        feat2 = self.relu(feat2)
        feat3 = nn.functional.interpolate(feat3, size=(32, 24), mode='bilinear')
        feat3 = self.BN(feat3)
        feat3 = self.relu(feat3)

        # 权重融合不同尺度的特征图
        fused_feat = feat1 * weights[0] + feat2 * weights[1] + feat3 * weights[2]

        return fused_feat


"""变形卷积模块"""


class DeformConv2d(nn.Module):
    """
    此为可变卷积核，作为可变神经网络的核与池化基础
    """

    def __init__(self, inc, out_c, kernel_size=3, padding=1, bias=None):
        """
        :param inc:  input channel \n
        :param out_c:  output channel \n
        :param kernel_size: 核大小 \n
        :param padding: 是否进行零填充 \n
        :param bias: 是否偏置 \n
        """
        super(DeformConv2d, self).__init__()  # 继承
        self.kernel_size = kernel_size
        self.padding = padding
        self.zero_padding = nn.ZeroPad2d(padding)  # 零填充
        self.conv_kernel = nn.Conv2d(inc, out_c, kernel_size=kernel_size, stride=kernel_size, bias=bias)

    def forward(self, x, offset):
        data_type = offset.data.type()
        kernel_size = self.kernel_size
        n = offset.size(1) // 2

        offset_index = Variable(torch.cat([torch.arange(0, 2 * n, 2),
                                           torch.arange(1, 2 * n + 1, 2)]),
                                requires_grad=False).type_as(x).long()
        # 增加和变换维度
        offset_index = offset_index.unsqueeze(dim=0).unsqueeze(dim=-1).unsqueeze(dim=-1).expand(*offset.size())
        # 偏移量，即delta p
        offset = torch.gather(offset, dim=1, index=offset_index)
        # 检查是否需要进行零填充
        if self.padding:
            x = self.zero_padding(x)

        p = self.get_p(offset, data_type)
        # 得到p，其结构为(b, 2n, h, w)
        p = p.contiguous().permute(0, 2, 3, 1)
        # 转换p，使其变为(b, h, w, 2n)

        # 下面使用双线性插值法进行学习，得到最后的偏移量
        q_lt = Variable(p.data, requires_grad=False).floor()
        q_rb = q_lt + 1

        # 三点表示多维度切片
        q_lt = torch.cat([torch.clamp(q_lt[..., :n], 0, x.size(2) - 1), torch.clamp(q_lt[..., n:], 0, x.size(3) - 1)],
                         dim=-1).long()
        q_rb = torch.cat([torch.clamp(q_rb[..., :n], 0, x.size(2) - 1), torch.clamp(q_rb[..., n:], 0, x.size(3) - 1)],
                         dim=-1).long()
        q_lb = torch.cat([q_lt[..., :n], q_rb[..., n:]], -1)
        q_rt = torch.cat([q_rb[..., :n], q_lt[..., n:]], -1)

        mask = torch.cat([p[..., :n].lt(self.padding) + p[..., :n].gt(x.size(2) - 1 - self.padding),
                          p[..., n:].lt(self.padding) + p[..., n:].gt(x.size(3) - 1 - self.padding)], dim=-1).type_as(p)
        # 得到(b, h, w, n)的结构
        mask = mask.detach()
        floor_p = p - (p - torch.floor(p))
        p = p * (1 - mask) + floor_p * mask
        p = torch.cat([torch.clamp(p[..., :n], 0, x.size(2) - 1), torch.clamp(p[..., n:], 0, x.size(3) - 1)], dim=-1)

        # 线性插值(b, h, w, n)
        g_lt = (1 + (q_lt[..., :n].type_as(p) - p[..., :n])) * (1 + (q_lt[..., n:].type_as(p) - p[..., n:]))
        g_rb = (1 - (q_rb[..., :n].type_as(p) - p[..., :n])) * (1 - (q_rb[..., n:].type_as(p) - p[..., n:]))
        g_lb = (1 + (q_lb[..., :n].type_as(p) - p[..., :n])) * (1 - (q_lb[..., n:].type_as(p) - p[..., n:]))
        g_rt = (1 - (q_rt[..., :n].type_as(p) - p[..., :n])) * (1 + (q_rt[..., n:].type_as(p) - p[..., n:]))

        # 得到(b, c, h, w, n)
        x_q_lt = self.get_xq(x, q_lt, n)
        x_q_rb = self.get_xq(x, q_rb, n)
        x_q_lb = self.get_xq(x, q_lb, n)
        x_q_rt = self.get_xq(x, q_rt, n)

        # 形成输出数据的结构(b, c, h, w, n)
        x_offset = (g_lt.unsqueeze(dim=1) * x_q_lt) + \
                   (g_rb.unsqueeze(dim=1) * x_q_rb) + \
                   (g_lb.unsqueeze(dim=1) * x_q_lb) + \
                   (g_rt.unsqueeze(dim=1) * x_q_rt)

        x_offset = self.reshape_the_offset(x_offset, kernel_size)
        out_x = self.conv_kernel(x_offset)

        return out_x

    def get_pn(self, n, data_type):
        p_n_x, p_n_y = np.meshgrid(range(-(self.kernel_size - 1) // 2, (self.kernel_size - 1) // 2 + 1),
                                   range(-(self.kernel_size - 1) // 2, (self.kernel_size - 1) // 2 + 1),
                                   indexing='ij')
        p_n = np.concatenate((p_n_x.flatten(), p_n_y.flatten()))  # (2n, 1)
        p_n = np.reshape(p_n, (1, 2 * n, 1, 1))
        p_n = Variable(torch.from_numpy(p_n).type(data_type), requires_grad=False)

        return p_n

    @staticmethod
    def get_p0(h, w, n, data_type):
        p0_x, p0_y = np.meshgrid(range(1, h + 1), range(1, w + 1), indexing='ij')
        p0_x = p0_x.flatten().reshape(1, 1, h, w).repeat(n, axis=1)
        p0_y = p0_y.flatten().reshape(1, 1, h, w).repeat(n, axis=1)
        p_0 = np.concatenate((p0_x, p0_y), axis=1)
        p_0 = Variable(torch.from_numpy(p_0).type(data_type), requires_grad=False)

        return p_0

    def get_p(self, offset, data_type):
        n, h, w = offset.size(1) // 2, offset.size(2), offset.size(3)
        p_n = self.get_pn(n, data_type)  # (1, 2n, 1, 1)
        p_0 = self.get_p0(h, w, n, data_type)  # (1, 2n, h, w)
        p = p_0 + p_n + offset
        return p

    @staticmethod
    def get_xq(x, q, n):
        b, h, w, _ = q.size()
        padded_w = x.size(3)
        c = x.size(1)
        x = x.contiguous().view(b, c, -1)  # (b, c, h*w)

        # (b, h, w, n)
        index = q[..., :n] * padded_w + q[..., n:]  # offset_x*w + offset_y
        # (b, c, h*w*n)
        index = index.contiguous().unsqueeze(dim=1).expand(-1, c, -1, -1, -1).contiguous().view(b, c, -1)

        x_offset = x.gather(dim=-1, index=index).contiguous().view(b, c, h, w, n)

        return x_offset

    @staticmethod
    def reshape_the_offset(x_offset, kernel_size):
        b, c, h, w, n = x_offset.size()
        x_offset = torch.cat([x_offset[..., s:s + kernel_size].contiguous().view(b, c, h, w * kernel_size) for s in
                              range(0, n, kernel_size)],
                             dim=-1)
        x_offset = x_offset.contiguous().view(b, c, h * kernel_size, w * kernel_size)

        return x_offset


"""END 变形卷积模块"""


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class StageModule(nn.Module):
    def __init__(self, input_branches, output_branches, c):
        """
        构建对应stage，即用来融合不同尺度的实现
        :param input_branches: 输入的分支数，每个分支对应一种尺度
        :param output_branches: 输出的分支数
        :param c: 输入的第一个分支通道数
        """
        super().__init__()
        self.input_branches = input_branches
        self.output_branches = output_branches
        # self.MVIT0 = MB_MobileViTBlock(32, 2, 32, 3, (4, 3), 64)
        # self.MVIT1 = MB_MobileViTBlock(64, 3, 64, 3, (4, 3), 128)
        # self.MVIT2 = MB_MobileViTBlock(128, 3, 128, 3, (4, 3), 256)
        # self.MVIT3 = MB_MobileViTBlock(256, 3, 256, 3, (4, 3), 512)
        # print("0001", count_parameters(self.MVIT0))
        # print("0001", count_parameters(self.MVIT1))
        # print("0001", count_parameters(self.MVIT2))
        # print("0001", count_parameters(self.MVIT3))
        self.branches = nn.ModuleList()
        for i in range(self.input_branches):  # 每个分支上都先通过4个BasicBlock
            w = c * (2 ** i)  # 对应第i个分支的通道数
            branch = nn.Sequential(
                BasicBlock(w, w),
                # BasicBlock(w, w),
                # BasicBlock(w, w),
                # BasicBlock(w, w)
            )
            self.branches.append(branch)

        self.fuse_layers = nn.ModuleList()  # 用于融合每个分支上的输出
        for i in range(self.output_branches):
            self.fuse_layers.append(nn.ModuleList())
            for j in range(self.input_branches):
                if i == j:
                    # 当输入、输出为同一个分支时不做任何处理
                    self.fuse_layers[-1].append(nn.Identity())
                elif i < j:
                    # 当输入分支j大于输出分支i时(即输入分支下采样率大于输出分支下采样率)，
                    # 此时需要对输入分支j进行通道调整以及上采样，方便后续相加
                    self.fuse_layers[-1].append(
                        nn.Sequential(
                            nn.Conv2d(c * (2 ** j), c * (2 ** i), kernel_size=1, stride=1, bias=False),
                            nn.BatchNorm2d(c * (2 ** i), momentum=BN_MOMENTUM),
                            nn.Upsample(scale_factor=2.0 ** (j - i), mode='nearest')
                        )
                    )
                else:  # i > j
                    # 当输入分支j小于输出分支i时(即输入分支下采样率小于输出分支下采样率)，
                    # 此时需要对输入分支j进行通道调整以及下采样，方便后续相加
                    # 注意，这里每次下采样2x都是通过一个3x3卷积层实现的，4x就是两个，8x就是三个，总共i-j个
                    ops = []
                    # 前i-j-1个卷积层不用变通道，只进行下采样
                    for k in range(i - j - 1):
                        ops.append(
                            nn.Sequential(
                                nn.Conv2d(c * (2 ** j), c * (2 ** j), kernel_size=3, stride=2, padding=1, bias=False),
                                nn.BatchNorm2d(c * (2 ** j), momentum=BN_MOMENTUM),
                                nn.ReLU(inplace=True)
                            )
                        )
                    # 最后一个卷积层不仅要调整通道，还要进行下采样
                    ops.append(
                        nn.Sequential(
                            nn.Conv2d(c * (2 ** j), c * (2 ** i), kernel_size=3, stride=2, padding=1, bias=False),
                            nn.BatchNorm2d(c * (2 ** i), momentum=BN_MOMENTUM)
                        )
                    )
                    self.fuse_layers[-1].append(nn.Sequential(*ops))

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):

        # 每个分支通过对应的block
        x = [branch(xi) for branch, xi in zip(self.branches, x)]
        # 接着融合不同尺寸信息

        x_fused = []
        for i in range(len(self.fuse_layers)):
            x_fused.append(
                self.relu(
                    sum([self.fuse_layers[i][j](x[j]) for j in range(len(self.branches))])
                )
            )

        return x_fused


class HR_MiT_Snet(nn.Module):
    def __init__(self, base_channel: int = 16, input_channel: int = 3, num_joints: int = 17):
        super(HR_MiT_Snet, self).__init__()
        L = [2, 4, 3]
        dims = [8, 8, 8]
        stage0_channel_List = [input_channel, 3, 9, base_channel]
        self.stage0 = nn.Sequential(
            nn.Conv2d(stage0_channel_List[0], stage0_channel_List[1], kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(stage0_channel_List[1], momentum=BN_MOMENTUM),
            nn.ReLU(inplace=True),
            nn.Conv2d(stage0_channel_List[1], stage0_channel_List[2], kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(stage0_channel_List[2], momentum=BN_MOMENTUM),
            nn.ReLU(inplace=True),
            nn.Conv2d(stage0_channel_List[2], stage0_channel_List[3], kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(stage0_channel_List[3], momentum=BN_MOMENTUM),
            nn.ReLU(inplace=True)
        )

        self.dropout = Dropout(p=DROPOUT)

        self.stage1_tunnel_0 = nn.Sequential(
            # DepthWiseConv(base_channel, base_channel, kernel_size=3, stride=2, padding=1),
            # nn.BatchNorm2d(base_channel, momentum=BN_MOMENTUM),
            # nn.ReLU(inplace=True),
            GhostModule(base_channel, base_channel * 2),
            # MV2Block(base_channel * 2, base_channel * 2, stride=1, expansion=4),
            MobileViTBlock(dims[0], L[0], base_channel * 2, kernel_size=3, patch_size=(4, 3), mlp_dim=int(dims[0] * 2))
        )

        self.DeformConv2D_0 = DeformConv2d(base_channel * 2, base_channel * 2)
        self.offset_01 = nn.Conv2d(base_channel * 2, 18, kernel_size=3, padding=1)
        self.BN_DFC_01 = nn.BatchNorm2d(base_channel * 2, momentum=BN_MOMENTUM)

        self.DeformConv2D_1 = DeformConv2d(base_channel * 4, base_channel * 4)
        self.offset_02 = nn.Conv2d(base_channel * 4, 18, kernel_size=3, padding=1)
        self.BN_DFC_02 = nn.BatchNorm2d(base_channel * 4, momentum=BN_MOMENTUM)

        self.DeformConv2D_3 = DeformConv2d(base_channel * 8, base_channel * 8)
        self.offset_03 = nn.Conv2d(base_channel * 8, 18, kernel_size=3, padding=1)
        self.BN_DFC_03 = nn.BatchNorm2d(base_channel * 8, momentum=BN_MOMENTUM)

        self.ReLU_DFConv = nn.ReLU(0)

        self.stage1_tunnel_1 = nn.Sequential(
            # DepthWiseConv(base_channel, base_channel, kernel_size=3, stride=2, padding=1),
            # nn.BatchNorm2d(base_channel, momentum=BN_MOMENTUM),
            # nn.ReLU(inplace=True),
            DepthWiseConv(base_channel, base_channel * 2, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(base_channel * 2, momentum=BN_MOMENTUM),
            nn.ReLU(inplace=True),
            GhostModule(base_channel * 2, base_channel * 4),
            MobileViTBlock(dims[1], L[1], base_channel * 4, kernel_size=3, patch_size=(4, 3), mlp_dim=int(dims[0] * 2))
        )
        self.stage1_tunnel_2 = nn.Sequential(
            SC2.ShuffleNetV2_channel_02(scale=2.0, in_channels=8, num_classes=10, SE=True, residual=True),
        )
        # self.fuse_stage = fuse_Block()
        self.stage_final = nn.Sequential(
            StageModule(input_branches=2, output_branches=1, c=(base_channel * 2)),
        )

        self.final_layer = nn.Conv2d(base_channel * 2, num_joints, kernel_size=1, stride=1)
        #
        #
        # self.DconvC1_0 = DepthWiseConv(base_channel, base_channel, 3, 2, 1)
        #
        # self.bnC_input = nn.BatchNorm2d(input, momentum=BN_MOMENTUM)
        # # self.
        #
        # self.ghostConv0 = GhostModule(3, base_channel)
        # self.bn0 = nn.BatchNorm2d(base_channel, momentum=BN_MOMENTUM)
        # self.relu = nn.ReLU(inplace=True)
        # self.ghostConv1 = GhostModule(base_channel, base_channel * 2)
        # self.bn1 = nn.BatchNorm2d(base_channel * 2, momentum=BN_MOMENTUM)
        # # self.ghostConv2 = GhostModule(64, 80)
        # # self.bn2 = nn.BatchNorm2d(80, momentum=BN_MOMENTUM)
        # # self.ghostConv3 = GhostModule(80, 128)
        # self.bn3 = nn.BatchNorm2d(base_channel * 4, momentum=BN_MOMENTUM)
        #
        # self.mv2_0 = nn.ModuleList([])
        # self.mv2_0.append(MV2Block(base_channel, base_channel, 1, expansion=4))
        # self.mv2_0.append(MV2Block(base_channel, base_channel, 1, expansion=4))
        # self.mv2_0.append(MV2Block(base_channel, base_channel, 1, expansion=4))
        #

        # self.conv_dc_x0 = nn.Conv2d(base_channel, 18, kernel_size=3, padding=1)
        #
        # self.mvit_0 = nn.ModuleList([])
        # self.mvit_0.append(MobileViTBlock(dims[0], L[0], base_channel, 3, (4, 3), int(dims[0] * 2)))
        # self.mvit_0.append(MobileViTBlock(dims[1], L[1], base_channel, 3, (4, 3), int(dims[1] * 3)))
        # self.mvit_0.append(MobileViTBlock(dims[2], L[1], base_channel, 3, (4, 3), int(dims[2] * 2)))
        #
        # self.mv2_1 = nn.ModuleList([])
        # self.mv2_1.append(MV2Block(base_channel * 2, base_channel * 2, 1, expansion=4))
        # self.mv2_1.append(MV2Block(base_channel * 2, base_channel * 2, 1, expansion=4))
        # self.mv2_1.append(MV2Block(base_channel * 2, base_channel * 2, 1, expansion=4))
        #

        # self.conv_dc_x1 = nn.Conv2d(base_channel * 2, 18, kernel_size=3, padding=1)
        #
        # self.mvit_1 = nn.ModuleList([])
        # self.mvit_1.append(MobileViTBlock(dims[0], L[0], base_channel * 2, 3, (4, 3), int(dims[0] * 2)))
        # self.mvit_1.append(MobileViTBlock(dims[1], L[1], base_channel * 2, 3, (4, 3), int(dims[1] * 3)))
        # # self.mvit_1.append(MobileViTBlock(dims[2], L[1], base_channel * 2, 3, (4, 3), int(dims[2] * 2)))
        #
        # self.SFC_2 = SC2.ShuffleNetV2_channel_02(scale=2.0, in_channels=base_channel * 2, num_classes=10, SE=True,
        #                                          residual=True)
        #
        # self.Dconv3_0 = DepthWiseConv(base_channel * 4, base_channel * 4, 3, 2, 1)
        #
        # self.SFC_3 = SC3.ShuffleNetV2_channel_03(scale=2.0, in_channels=base_channel * 4, num_classes=10, SE=True,
        #                                          residual=True)
        #

    def forward(self, x):
        # print("初始batchsize", x.shape)
        """深度可分离卷积特征降维 ([1, 3, 256, 192]) -》([1, 3, 64, 48])"""
        x = self.stage0(x)
        # print("Dconv 卷积降维", x.shape)
        """ghost 模块通道扩展([1, 3, 256, 192]) -》([1, 32, 64, 48])"""

        # x = self.ghostConv0(x)
        # # print("Ghost 通道扩展", x.shape)
        #
        """ 0号通道 mobile VIT 高分辨率 特征提取 torch.Size([1,16,32,24])"""
        x0 = self.stage1_tunnel_0(x)
        x0 = self.DeformConv2D_0(x0, self.offset_01(x0))
        x0 = self.BN_DFC_01(x0)
        x0 = self.ReLU_DFConv(x0)
        x0 = self.dropout(x0)

        # x0 = self.mv2_0[0](x)
        # x0 = self.mvit_0[0](x0)
        # """变形卷积，特征强化"""
        # x0 = self.dc_x0(x0, self.conv_dc_x0(x0))
        # x0 = self.bn0(x0)
        # x0 = self.relu(x0)
        # # print("0号通道特征输出", x0.shape)
        """ 0号通道 mobile VIT 高分辨率 特征提取 torch.Size([1, 16,32,24])"""
        #
        # """通道继续降维 ([1, 32, 64, 48])-》([1, 32, 32, 24]) """
        # x = self.DconvC1_0(x)
        # x = self.bn0(x)
        # x = self.relu(x)
        # x = self.ghostConv1(x)
        # # print("Dconv 第二次卷积降维+通道扩展", x.shape)
        #
        """ 1号通道 mobile VIT 高分辨率 特征提取torch.Size([1, 64, 32, 24]) """
        x1 = self.stage1_tunnel_1(x)
        x1 = self.DeformConv2D_1(x1, self.offset_02(x1))
        x1 = self.BN_DFC_02(x1)
        x1 = self.ReLU_DFConv(x1)
        x1 = self.dropout(x1)
        # x1 = self.mv2_1[0](x)
        # x1 = self.mvit_1[0](x1)
        #
        # """变形卷积，特征强化"""
        # x1 = self.dc_x1(x1, self.conv_dc_x1(x1))
        # x1 = self.bn1(x1)
        # x1 = self.relu(x1)
        # # print("1号通道特征输出", x1.shape)
        # """ END 1号通道 mobile VIT 高分辨率 特征提取 torch.Size([1, 64, 32, 24])"""
        #
        # """2号通道 ShuffleNET 通道 """
        # x2 = self.SFC_2(x)
        # """END 2号通道 ShuffleNET 通道 """
        #
        # """3号通道 ShuffleNET 通道 """
        # x3 = self.Dconv3_0(x2)
        # x3 = self.bn3(x3)
        # x3 = self.relu(x3)
        # #
        # x3 = self.SFC_3(x3)
        # """END 3号通道 ShuffleNET 通道 """
        #
        # out = self.fuse(x0, x1, x2, x3)
        # print(x.shape, x0.shape, x1.shape)
        """ 1号通道 [1, 64, 32, 24]) """
        """ 2号通道 ([1, 128, 4,3]) """
        # x2 = self.stage1_tunnel_2(x)
        # x2 = self.DeformConv2D_3(x2, self.offset_03(x2))
        # x2 = self.BN_DFC_03(x2)
        # x2 = self.ReLU_DFConv(x2)
        """ 2号通道 ([1, 128, 4,3]) """

        """融合通道"""
        # print(x0.shape, x1.shape, x2.shape)
        x_list = [x0, x1]
        out = self.stage_final(x_list)
        out = self.final_layer(out[0])
        # print(x0.shape, x1.shape, x2.shape)
        #

        # fig = plt.figure(figsize=(10, 10))
        # out = out.cpu()
        # out = out.detach().numpy()
        # for i in range(17):
        #     ax = fig.add_subplot(4, 5, i + 1)
        #     img = out[0, i, :, :]
        #     ax.imshow(img)
        #     ax.axis("off")
        #
        # plt.show()
        #
        # os._exit(0)
        return out

    #
    # Dconv0 = DepthWiseConv(3, 32, 3, 2, 1)
    # Dconv1 = DepthWiseConv(32, 32, 3, 2, 1)
    # out = Dconv0(pic)
    # out = Dconv1(out)
    # dc0 = DeformConv2d(3, 64)
    # conv0 = nn.Conv2d(3, 18, kernel_size=3, padding=1)
    # out000 = dc0(pic, conv0(pic))
    # print(count_parameters(dc0))
    # print(out000.shape)
    # depth = 0
    # def count_layers(m):
    #     global depth
    #     for child in m.children():
    #         if isinstance(child, nn.Sequential):
    #             depth += 1
    #         count_layers(child)
    #
    # count_layers(model0)
    # print(f"Depth: {depth}")


# # pic = torch.randn(1, 3, 256, 192)
# # # print(type(pic))
# # model0 = HR_MiT_Snet()
# # out = model0(pic)
# # print(out.shape)
# # print(count_parameters(model0))
# base_channel = 32
# img0 = torch.randn(1, 32, 32, 24)  # 8*6
# img1 = torch.randn(1, 64, 16, 12)  # 4*3
# img2 = torch.randn(1, 128, 8, 6)
#
# x_list = [img0, img1, img2]
# # img3 = torch.randn(1, 256, 8, 6)
# stage_final = nn.Sequential(
#     StageModule(input_branches=3, output_branches=3, c=base_channel),
#                             StageModule(input_branches=3, output_branches=1, c=base_channel),
#                             )
# out = stage_final(x_list)
# final_layer = nn.Conv2d(base_channel, 17, kernel_size=1, stride=1)
# out = final_layer(out[0])
# print(out.shape)
x = torch.randn(1, 3, 3, 3)

# fig_x = plt.figure(figsize=(20, 20))
# for i in range(3):
#     ax = fig_x.add_subplot(3, 3, i + 1)
#     img = x[0, i, :, :]
#     ax.imshow(img)
#     ax.axis("off")
# plt.show()


# print(y, y.shape)
