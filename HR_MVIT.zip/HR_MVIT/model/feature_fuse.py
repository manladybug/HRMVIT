import torch
import torch.nn as nn


# 定义3个不同尺度的特征图
# feat1 = torch.randn(1, 32, 32, 24)
# feat2 = torch.randn(1, 64, 16, 12)
# feat3 = torch.randn(1, 128, 4, 3)


def stage2_fuse(feat1, feat2, feat3):
    # 计算每个特征图的权重,分辨率越高权重越大
    weights = [0.5, 0.3, 0.2]

    # 使用1x1卷积调整channel数到统一尺度
    conv1 = nn.Conv2d(32, 17, 1)
    conv2 = nn.Conv2d(64, 17, 1)
    conv3 = nn.Conv2d(128, 17, 1)

    feat1 = conv1(feat1)
    feat2 = conv2(feat2)
    feat3 = conv3(feat3)

    # 使用双线性插值调整spatial尺寸
    feat1 = nn.functional.interpolate(feat1, size=(32, 24), mode='bilinear')
    feat2 = nn.functional.interpolate(feat2, size=(32, 24), mode='bilinear')
    feat3 = nn.functional.interpolate(feat3, size=(32, 24), mode='bilinear')

    # 权重融合不同尺度的特征图
    fused_feat = feat1 * weights[0] + feat2 * weights[1] + feat3 * weights[2]

    return fused_feat
