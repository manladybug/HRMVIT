import matplotlib.pyplot as plt
import numpy as np
import math
import torch


def showF(feature_map, rows, cols):

    # define number of rows and columns for the subplot
    rows = rows
    cols = cols

    # create the subplot
    fig, axs = plt.subplots(rows, cols, figsize=(10, 10))

    # loop over each channel and plot the corresponding heatmap
    for i in range(rows):
        for j in range(cols):
            channel = i * cols + j
            if channel < feature_map.shape[1]:
                axs[i, j].imshow(feature_map[channel, :, :], cmap='gray')
            else:
                axs[i, j].axis('off')

    # show the plot
    plt.show()
